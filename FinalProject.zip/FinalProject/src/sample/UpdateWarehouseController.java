package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Control;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class UpdateWarehouseController extends DBConnect implements Initializable {

    public static String price;
    public static String qty;
    public static String item;

    @FXML
    TextField qtyAmount;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        qtyAmount.setText(qty);
    }

    public void update() throws IOException {

        String sql1 = String.format("update warehouse set Qty = '%s' where item = '%s' ", qtyAmount.getText(), item);


        System.out.println(sql1);


        try {
            st = con.createStatement();
            st.executeUpdate(sql1);

            System.out.println("Data Updated");
        } catch (Exception e) {
            System.out.println(e);
        }
        if(Integer.parseInt(qtyAmount.getText()) < Integer.parseInt(qty)){
            updateData(qtyAmount.getText(),UpdateWarehouseController.item);
            backToWarehouse();

        }
        else{
            int tempCapital = Integer.parseInt(qtyAmount.getText()) * Integer.parseInt(UpdateWarehouseController.price);
            int currCapital = returnCapital() + tempCapital;
            updateData(qtyAmount.getText(),UpdateWarehouseController.item);
            updateCapital(Integer.toString(currCapital));
            backToWarehouse();
        }

    }

    public void backToWarehouse() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AfterCheck2.fxml"));



        Controller.warehouseStage.setScene(new Scene(root, 600, 400));
        Controller.warehouseStage.setResizable(false);
        Controller.warehouseStage.show();
        qty ="";
    }

}
