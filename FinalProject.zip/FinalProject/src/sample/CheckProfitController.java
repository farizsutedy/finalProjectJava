package sample;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.text.Text;

import java.net.URL;
import java.util.ResourceBundle;

public class CheckProfitController extends DBConnect implements Initializable {

    public static int totalProfit = 0;//set total ptofit as 0
    public static int totalCapital = 0;

    @FXML
    Text profitAmount;
    @FXML
    Text capitalAmount;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        String profit = Integer.toString(returnProfit());
        String capital = Integer.toString(returnCapital());

        profitAmount.setText(profit);
        capitalAmount.setText(capital);

    }
}
