package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;


import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class AfterHistoryControl extends DBConnect implements Initializable {//extend to dbconnect

    @FXML
    TableView table;
    @FXML
    TableColumn itemColumn;

    @FXML
    TableColumn capPriceColumn;

    @FXML
    TableColumn soldPriceColumn;

    ObservableList<HistoryItem> Row = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        updateData();
    }
    public void updateData(){//void to show the history every after selling
        table.getItems().clear();
        try{
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM history");
            while (rs.next()) {
/*
                String item = rs.getString("item");
                String Price2 = rs.getString("capPrice");
                String price = rs.getString("soldPrice");
                //System.out.println(item);
                */
                Row.add(new HistoryItem(rs.getString("item"),rs.getString("capPrice"),rs.getString("soldPrice")));
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        itemColumn.setCellValueFactory(new PropertyValueFactory<HistoryItem, String>("item"));
        capPriceColumn.setCellValueFactory(new PropertyValueFactory<HistoryItem, String>("price2"));
        soldPriceColumn.setCellValueFactory(new PropertyValueFactory<HistoryItem, String>("Price"));
        table.setItems(Row);
    }
}

/*
void getData(){

    }
 */
