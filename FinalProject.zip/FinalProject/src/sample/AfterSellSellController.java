package sample;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;


public class AfterSellSellController extends Controller implements Initializable {
    DBConnect connect = new DBConnect();
    @FXML
    TextField cap;
    @FXML
    TextField price;
    @FXML
    TextField nameFlower;
    @FXML
    TextArea ingridients;

    public static int totalPrice = 0;   //there will be empty space if you dont put any item in selling
    public static String item = "";
    public static String qty = "";

    public static ArrayList<String> arrayListItem =  new ArrayList<>();
    public static ArrayList<String> arrayListQty = new ArrayList<>();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        String temp = "";
        String totalPriceAsString = Integer.toString(totalPrice);//change the int to string after the total price
        cap.setText(totalPriceAsString);
        System.out.println("price" + totalPriceAsString);//print the total price as string
        for (int counter = 0; counter < arrayListItem.size(); counter++) {
            temp += arrayListItem.get(counter) + "         qty = " + arrayListQty.get(counter) + "\n";
        }
        System.out.println(temp);
        ingridients.setText(temp);
        arrayListItem.clear();
        arrayListQty.clear();
    }

    public void sellItem(){
        String itemm = nameFlower.getText();//selling the item void
        String capPrice = cap.getText();
        String soldPrice = price.getText();

        totalPrice = 0;//total price set as 0 first
        AfterSellingControl.afterSellSell.close();
        System.out.println("ITEM SOLD ! ");//print if all item successfully sold
        int profit = Integer.parseInt(soldPrice) - Integer.parseInt(capPrice);
        CheckProfitController.totalProfit += profit;//total price will minu the capital price and put in the profit

        connect.insertHistory(itemm , capPrice , soldPrice);
        System.out.println(connect.returnProfit()+profit);
        connect.updateProfit(connect.returnProfit()+profit);
        item = "";
        qty = "";


    }
}
