package sample;

import javafx.beans.property.SimpleStringProperty;

public class AfterCheckItem {

    SimpleStringProperty Item,QTY,Price;

    public AfterCheckItem(String Item,String QTY,String Price){//showing the table when you touch button check
        this.Item=new SimpleStringProperty(Item);
        this.QTY=new SimpleStringProperty(QTY);
        this.Price=new SimpleStringProperty(Price);
    }

    public String getItem() { return Item.get(); }
    public String getQTY() { return QTY.get(); }
    public String getPrice() { return Price.get(); }

}
