package sample;
import java.sql.*;

public class DBConnect {

    public Connection con;
    public Statement st;
    public ResultSet rs;


    public static Connection getConnection() throws SQLException, ClassNotFoundException {

        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalprojectjava?serverTimezone=UTC", "root", "");

        return connection;

    }

    DBConnect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Create Connection
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalprojectjava?serverTimezone=UTC", "root", "");
            st = con.createStatement();
        } catch (Exception e) {
            System.out.println("Error : " + e);
        }
    }


    void insertData(String Item, String QTY, String Price) {//inserting all data such as item, Qty, Price
        String sql = String.format("insert into warehouse(Item, Qty, Price) VALUES('%s', '%s' ,'%s')", Item, QTY, Price);
        System.out.println(sql);
        try {
            st = con.createStatement();
            st.executeUpdate(sql);
            System.out.println("Data Inserted");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void updateData(String qty, String item) {//update the data in check warehouse

        String sql = String.format("update warehouse set qty = '%s' where item = '%s' ", qty, item);

        System.out.println(sql);
        try {
            st = con.createStatement();
            st.executeUpdate(sql);
            System.out.println("Data Updated");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void insertHistory(String item, String capPrice, String soldPrice) {//insert the selling history to history button
        String sql = String.format("insert into history(item, capPrice, soldPrice) VALUES('%s', '%s' ,'%s')", item, capPrice, soldPrice);

        System.out.println(sql);
        try {
            st = con.createStatement();
            st.executeUpdate(sql);
            System.out.println("Data Updated");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void updateProfit(int amount) {//update the profit for every transaction
        String sql = String.format("update balance set amount = '%s' where type = 'profit' ", amount);

        System.out.println(sql);
        try {
            st = con.createStatement();
            st.executeUpdate(sql);
            System.out.println("Profit Updated");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void updateCapital(String amount) {//update capital for every spend budget
        String sql = String.format("update balance set amount = '%s' where type = 'capital' ", amount);

        System.out.println(sql);
        try {
            st = con.createStatement();
            st.executeUpdate(sql);
            System.out.println("Amount Updated");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public int returnProfit() {
        String query = "select * from balance";
        int profit = 0;
        try {
            rs = st.executeQuery(query);
            System.out.println("Records from Database");
            // PRINTING DATA
            while (rs.next()) {
                if (rs.getString("type").equals("profit")) {
                    String profitt = rs.getString("amount");
                    profit = Integer.parseInt(profitt);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return profit;
    }
    public int returnCapital() {//count the capital as proify minus with capital price
        String query = "select * from balance";
        int profit = 0;
        try {
            rs = st.executeQuery(query);
            System.out.println("Records from Database");
            // PRINTING DATA
            while (rs.next()) {
                if (rs.getString("type").equals("capital")) {
                    String profitt = rs.getString("amount");
                    profit = Integer.parseInt(profitt);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return profit;
    }

    void deleteIFZero(){//if in the warehouse there i an item with 0 QTY, will delete the item in warehouse

        String sql = String.format("delete from warehouse where Qty = '0' ");//delete every item in warehouse if qty 0

        try {
            st = con.createStatement();
            st.executeUpdate(sql);
            System.out.println("Row Deleted");
        } catch (Exception e){
            System.out.println(e);
        }
    }
}
