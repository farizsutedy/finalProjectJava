package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller {

    public static Stage warehouseStage;
    public static Stage sellStage;
    public static Stage addStage;



    public static Stage afterAdd;
    public static Stage afterSell;
    public void GoToAfterHistory() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AfterHistory.fxml"));


        Stage historyStage = new Stage();

        historyStage.setScene(new Scene(root, 600, 400));
        historyStage.setResizable(false);
        historyStage.show();
    }
    public void GoToAfterSell() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AfterSelling.fxml"));

        sellStage = new Stage();

        sellStage.setScene(new Scene(root, 600, 400));
        sellStage.setResizable(false);
        sellStage.show();
    }
    public void GoToAfterAdd() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AfterCheck2.fxml"));

        warehouseStage = new Stage();

        warehouseStage.setScene(new Scene(root, 600, 400));
        warehouseStage.setResizable(false);
        warehouseStage.show();
    }
    public void GoToAfterAdd1() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AfterAdd2.fxml"));


        addStage = new Stage();

        addStage.setScene(new Scene(root, 600, 400));
        addStage.setResizable(false);
        addStage.show();
    }

    public void goToCheckProfit() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("checkProfit.fxml"));


        afterAdd = new Stage();

        afterAdd.setScene(new Scene(root, 600, 400));
        afterAdd.setResizable(false);
        afterAdd.show();
    }

}
