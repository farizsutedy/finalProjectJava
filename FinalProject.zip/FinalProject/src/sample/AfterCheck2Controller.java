package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class AfterCheck2Controller extends DBConnect implements Initializable {//extend to dbconnect
    public TableView<AfterCheckItem> table;
    public TableColumn<AfterCheckItem, String> itemColumn ,qtyColumn, priceColumn;

    ObservableList<AfterCheckItem> Row = FXCollections.observableArrayList();// to put in the row


    public void update() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("updateWarehouse.fxml"));//open fxml



        Controller.warehouseStage.setScene(new Scene(root, 600, 400));
        Controller.warehouseStage.setResizable(false);

        UpdateWarehouseController.price = table.getSelectionModel().getSelectedItem().getPrice();
        UpdateWarehouseController.qty = table.getSelectionModel().getSelectedItem().getQTY();
        UpdateWarehouseController.item = table.getSelectionModel().getSelectedItem().getItem();

        int tempCapital = Integer.parseInt(UpdateWarehouseController.qty) * Integer.parseInt(UpdateWarehouseController.price);
        int currCapital = returnCapital() -tempCapital;//update capital after update
        updateCapital(Integer.toString(currCapital));
        UpdateWarehouseController.item = table.getSelectionModel().getSelectedItem().getItem();
        System.out.println(UpdateWarehouseController.qty);

    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {//void if the QTY in item0, it will delete yhe item in table
        try{
            deleteIFZero();//
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM warehouse");
            while (rs.next()) {
                String item = rs.getString("Item");
                String qty = rs.getString("Qty");
                String price = rs.getString("Price");
                System.out.println(item);
                Row.add(new AfterCheckItem(item,qty,price));
            }
            itemColumn.setCellValueFactory(new PropertyValueFactory<AfterCheckItem, String>("Item"));
            qtyColumn.setCellValueFactory(new PropertyValueFactory<AfterCheckItem, String>("QTY"));
            priceColumn.setCellValueFactory(new PropertyValueFactory<AfterCheckItem, String>("Price"));
            table.setItems(Row);
        }
        catch (Exception e ){
            e.printStackTrace();
        }

    }
}
