package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;


public class AfterSellingControl extends DBConnect implements Initializable {
    DBConnect connect2 = new DBConnect();


    public static Stage afterSellSell;
    public static Stage afterSellCreate;

    public TableView<AfterCheckItem> table;
    public TableColumn<AfterCheckItem, String> itemColumn ,qtyColumn, priceColumn;


    ObservableList<AfterCheckItem> Row = FXCollections.observableArrayList();

    @FXML
    TextField addQty;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        updateData();
    }

    public void updateData(){
        deleteIFZero();
        table.getItems().clear();
        try{
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM warehouse");
            while (rs.next()) {
                String item = rs.getString("Item");
                String qty = rs.getString("Qty");
                String price = rs.getString("Price");
                //System.out.println(item);
                Row.add(new AfterCheckItem(item,qty,price));
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }

        itemColumn.setCellValueFactory(new PropertyValueFactory<AfterCheckItem, String>("Item"));
        qtyColumn.setCellValueFactory(new PropertyValueFactory<AfterCheckItem, String>("QTY"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<AfterCheckItem, String>("Price"));
        table.setItems(Row);
    }
    public void GoToAfterSellSell() throws IOException { //to catch io error
    Parent root = FXMLLoader.load(getClass().getResource("afterSellSell.fxml"));
    afterSellSell = new Stage();

    afterSellSell.setScene(new Scene(root, 600, 400));
    afterSellSell.setResizable(false);
    afterSellSell.show();   //show the after sell sell
    Controller.sellStage.close();
}


    public void addToCart(){//put everythin to chart after you put the ingredient
        int temp = Integer.parseInt(table.getSelectionModel().getSelectedItem().getPrice());
        String item = table.getSelectionModel().getSelectedItem().getItem();
        int qty1 = Integer.parseInt(table.getSelectionModel().getSelectedItem().getQTY());


        int qty2 = Integer.parseInt(addQty.getText());

        int price = temp * qty2;//price count as price multiply with integer we put in
        int result = qty1-qty2;//QTY reduce with number we choose


        if(result<0){
            System.out.println("QTY KEGEDEAN");//if the number we choose higher than the exact quantity
            addQty.setText("");
        }
        else{
            addQty.setText("");
            connect2.updateData(Integer.toString(result),item);

            updateData();
            System.out.println(price);
            AfterSellSellController.totalPrice+=price;
            System.out.println(AfterSellSellController.totalPrice);

            String qtyAsString = Integer.toString(qty2);

            AfterSellSellController.arrayListItem.add(item);
            AfterSellSellController.arrayListQty.add(qtyAsString);
        }

    }


}
