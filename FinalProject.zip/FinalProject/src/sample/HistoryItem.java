package sample;

import javafx.beans.property.SimpleStringProperty;

public class HistoryItem {
    private  SimpleStringProperty item,price2,price;//putting the history selling to the history table

    public HistoryItem(String Item,String capPrice,String Price){
        this.item =new SimpleStringProperty(Item);
        this.price2 =new SimpleStringProperty(capPrice);
        this.price=new SimpleStringProperty(Price);
    }


    public String getItem() {
        return item.get();
    }


    public String getPrice2() {
        return price2.get();
    }

    public String getPrice() {
        return price.get();
    }

}
