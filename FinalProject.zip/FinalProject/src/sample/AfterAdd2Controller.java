package sample;


import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class AfterAdd2Controller extends DBConnect {
    DBConnect connect = new DBConnect();
    @FXML
    TextField Item;
    @FXML
    TextField QTY ;
    @FXML
    TextField Price;

    public void Save(){
        String Item=this.Item.getText();    //to put the item in string and save it
        String QTY=this.QTY.getText();
        String Price=this.Price.getText();

        int capital = Integer.parseInt(Price) * Integer.parseInt(QTY); //count the capital number
        insertData(Item,QTY,Price);//insert data for item, qty, price
        //CheckProfitController.totalCapital += capital;
        String capitalAsString = Integer.toString(returnCapital()+capital);//count capital before and after to make final capital
        System.out.println(capitalAsString);
        updateCapital(capitalAsString);
        Controller.addStage.close();
    }
}
